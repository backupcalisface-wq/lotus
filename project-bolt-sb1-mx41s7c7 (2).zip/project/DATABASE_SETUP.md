# 🔧 Configuração do Banco de Dados

## ⚠️ PROBLEMA IDENTIFICADO

O banco de dados Supabase configurado atualmente **NÃO TEM PRIVILÉGIOS DE ACESSO**.

**Diagnóstico completo:**
- ✅ Variáveis de ambiente existem no `.env`
- ❌ Token JWT está expirado ou inválido
- ❌ Conta Supabase não tem permissões necessárias
- ✅ Migrações SQL estão prontas para serem aplicadas

---

## 🎯 SOLUÇÃO COMPLETA

### Opção 1: Criar Novo Projeto Supabase (RECOMENDADO)

1. **Acesse https://supabase.com/dashboard**

2. **Crie um novo projeto:**
   - Clique em "New Project"
   - Nome: `nail-salon` (ou nome de sua preferência)
   - Database Password: Crie uma senha forte
   - Region: Escolha a mais próxima de você

3. **Obtenha as credenciais:**
   - Vá em Settings → API
   - Copie:
     - `Project URL` (algo como https://xxxxx.supabase.co)
     - `anon` `public` key

4. **Atualize o arquivo `.env`:**
   ```env
   VITE_SUPABASE_URL=https://seu-projeto.supabase.co
   VITE_SUPABASE_ANON_KEY=sua-chave-anon-aqui
   ```

5. **Execute as migrações no Supabase Dashboard:**
   - Vá em SQL Editor no dashboard
   - Execute cada arquivo SQL em ordem:

**Arquivo 1: Newsletter Subscriptions**
```sql
CREATE TABLE IF NOT EXISTS newsletter_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome_completo text NOT NULL,
  email text UNIQUE NOT NULL,
  whatsapp text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE newsletter_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can subscribe to newsletter"
  ON newsletter_subscriptions
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view all subscriptions"
  ON newsletter_subscriptions
  FOR SELECT
  TO authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS idx_newsletter_email ON newsletter_subscriptions(email);
CREATE INDEX IF NOT EXISTS idx_newsletter_created_at ON newsletter_subscriptions(created_at DESC);
```

**Arquivo 2: Blog Posts**
```sql
CREATE TABLE IF NOT EXISTS blog_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  summary text NOT NULL,
  content text NOT NULL,
  cover_image text NOT NULL,
  author_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  author_name text NOT NULL,
  published boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read published posts"
  ON blog_posts
  FOR SELECT
  USING (published = true);

CREATE POLICY "Authenticated users can read all posts"
  ON blog_posts
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create posts"
  ON blog_posts
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Authenticated users can update own posts"
  ON blog_posts
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Authenticated users can delete own posts"
  ON blog_posts
  FOR DELETE
  TO authenticated
  USING (auth.uid() = author_id);

CREATE INDEX IF NOT EXISTS idx_blog_posts_slug ON blog_posts(slug);
CREATE INDEX IF NOT EXISTS idx_blog_posts_published ON blog_posts(published, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_blog_posts_author ON blog_posts(author_id);

CREATE OR REPLACE FUNCTION update_blog_posts_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS blog_posts_updated_at ON blog_posts;
CREATE TRIGGER blog_posts_updated_at
  BEFORE UPDATE ON blog_posts
  FOR EACH ROW
  EXECUTE FUNCTION update_blog_posts_updated_at();
```

**Arquivo 3: Sistema de Login Customizado (IMPORTANTE)**
```sql
CREATE TABLE IF NOT EXISTS usuarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  senha text NOT NULL DEFAULT 'zk67v15G',
  nome text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read usuarios for login"
  ON usuarios
  FOR SELECT
  USING (true);

CREATE POLICY "Users can update own data"
  ON usuarios
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);

CREATE OR REPLACE FUNCTION update_usuarios_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS usuarios_updated_at ON usuarios;
CREATE TRIGGER usuarios_updated_at
  BEFORE UPDATE ON usuarios
  FOR EACH ROW
  EXECUTE FUNCTION update_usuarios_updated_at();

-- Insere o usuário padrão conforme solicitado
INSERT INTO usuarios (email, senha, nome)
VALUES ('romariolimadesantana30@gmail.com', 'zk67v15G', 'Romário Lima de Santana')
ON CONFLICT (email) DO NOTHING;
```

---

## 🔐 SISTEMA DE LOGIN IMPLEMENTADO

### Credenciais Padrão
- **Email:** `romariolimadesantana30@gmail.com`
- **Senha:** `zk67v15G`

### Estrutura da Tabela `usuarios`
```
id          → UUID único
email       → E-mail (único, usado para login)
senha       → Senha em texto plano
nome        → Nome completo do usuário
created_at  → Data de criação
updated_at  → Última atualização
```

### Como Funciona
1. Usuário digita e-mail e senha no formulário de login
2. Sistema busca na tabela `usuarios` pelo e-mail
3. Compara a senha digitada com a senha armazenada
4. Se correto → redireciona para o dashboard
5. Se incorreto → mostra mensagem de erro

---

## 🧪 TESTE APÓS CONFIGURAÇÃO

1. Reinicie o servidor de desenvolvimento (já feito automaticamente)
2. Abra o navegador em `https://localhost:5173`
3. A tela branca deve desaparecer
4. Teste o login com as credenciais padrão

---

## 📊 ESTRUTURA DO BANCO

### Tabelas Criadas:
1. ✅ `newsletter_subscriptions` - Inscrições na newsletter
2. ✅ `blog_posts` - Sistema de blog
3. ✅ `usuarios` - Sistema de autenticação customizado

### Segurança (RLS):
- ✅ Row Level Security habilitado em todas as tabelas
- ✅ Políticas configuradas para acesso controlado
- ✅ Índices criados para performance

---

## ⚡ PRÓXIMOS PASSOS

Após configurar o novo banco:

1. ✅ Aplicação vai carregar normalmente
2. ✅ Login funcionará com as credenciais padrão
3. ✅ Dashboard ficará acessível
4. ✅ Sistema de newsletter estará operacional
5. ✅ Blog estará pronto para uso

**Lembre-se:** Após criar o projeto no Supabase e executar os scripts SQL, atualize o arquivo `.env` com as novas credenciais!
