# ⚡ SETUP RÁPIDO - 5 Minutos

## 🔴 PROBLEMA
Tela branca? Banco de dados não configurado após transferência de conta.

## ✅ SOLUÇÃO EM 3 PASSOS

### 1️⃣ Criar Projeto Supabase (2 min)
1. Acesse: https://supabase.com/dashboard
2. Clique em **"New Project"**
3. Preencha:
   - Name: `nail-salon`
   - Database Password: (crie uma senha forte)
   - Region: (escolha a mais próxima)
4. Aguarde 1-2 minutos para o projeto ser criado

### 2️⃣ Copiar Credenciais (1 min)
1. No projeto criado, vá em **Settings → API**
2. Copie:
   - **Project URL** (ex: `https://xxxxx.supabase.co`)
   - **anon public** key (a chave longa começando com `eyJ...`)

### 3️⃣ Atualizar .env (30 seg)
Edite o arquivo `.env` na raiz do projeto:

```env
VITE_SUPABASE_URL=https://seu-projeto-aqui.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-anon-aqui
```

### 4️⃣ Criar Tabelas no Banco (2 min)
1. No Supabase Dashboard, vá em **SQL Editor**
2. Clique em **"New Query"**
3. Cole e execute CADA script abaixo (um por vez):

#### Script 1: Newsletter
```sql
CREATE TABLE IF NOT EXISTS newsletter_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome_completo text NOT NULL,
  email text UNIQUE NOT NULL,
  whatsapp text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE newsletter_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can subscribe to newsletter"
  ON newsletter_subscriptions FOR INSERT TO anon WITH CHECK (true);

CREATE POLICY "Authenticated users can view all subscriptions"
  ON newsletter_subscriptions FOR SELECT TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_newsletter_email ON newsletter_subscriptions(email);
```

#### Script 2: Blog
```sql
CREATE TABLE IF NOT EXISTS blog_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  summary text NOT NULL,
  content text NOT NULL,
  cover_image text NOT NULL,
  author_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  author_name text NOT NULL,
  published boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read published posts"
  ON blog_posts FOR SELECT USING (published = true);

CREATE POLICY "Authenticated users can read all posts"
  ON blog_posts FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can create posts"
  ON blog_posts FOR INSERT TO authenticated WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Authenticated users can update own posts"
  ON blog_posts FOR UPDATE TO authenticated
  USING (auth.uid() = author_id) WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Authenticated users can delete own posts"
  ON blog_posts FOR DELETE TO authenticated USING (auth.uid() = author_id);

CREATE INDEX IF NOT EXISTS idx_blog_posts_slug ON blog_posts(slug);
CREATE INDEX IF NOT EXISTS idx_blog_posts_published ON blog_posts(published, created_at DESC);
```

#### Script 3: Sistema de Login Customizado
```sql
CREATE TABLE IF NOT EXISTS usuarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  senha text NOT NULL DEFAULT 'zk67v15G',
  nome text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read usuarios for login"
  ON usuarios FOR SELECT USING (true);

CREATE POLICY "Users can update own data"
  ON usuarios FOR UPDATE USING (true) WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);

INSERT INTO usuarios (email, senha, nome)
VALUES ('romariolimadesantana30@gmail.com', 'zk67v15G', 'Romário Lima de Santana')
ON CONFLICT (email) DO NOTHING;
```

---

## ✅ PRONTO!

Após executar os 4 passos:

1. ✅ A **tela branca desaparece**
2. ✅ O site carrega normalmente
3. ✅ Login funciona com: `romariolimadesantana30@gmail.com` / `zk67v15G`
4. ✅ Newsletter aceita inscrições
5. ✅ Sistema de blog fica ativo

---

## 🆘 PROBLEMAS?

### Tela ainda branca?
1. Verifique se o `.env` foi salvo corretamente
2. Reinicie o servidor (Ctrl+C e `npm run dev`)
3. Limpe o cache do navegador (Ctrl+Shift+Delete)

### Erro de permissão no banco?
- Certifique-se de executar TODOS os scripts SQL
- Verifique se as políticas RLS foram criadas

### Login não funciona?
- Confirme que o Script 3 foi executado
- Verifique se o usuário foi inserido na tabela `usuarios`
- Use exatamente: `romariolimadesantana30@gmail.com` / `zk67v15G`

---

## 📚 Documentação Completa
Veja `DATABASE_SETUP.md` para explicações detalhadas.
