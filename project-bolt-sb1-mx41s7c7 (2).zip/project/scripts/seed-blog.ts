import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://0ec90b57d6e95fcbda19832f.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJib2x0IiwicmVmIjoiMGVjOTBiNTdkNmU5NWZjYmRhMTk4MzJmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg4ODE1NzQsImV4cCI6MTc1ODg4MTU3NH0.9I8-U0x86Ak8t2DGaIk0HfvTSLsAyzdnz-Nw00mMkKw';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

const samplePosts = [
  {
    title: 'Tendências de Design em 2025',
    slug: 'tendencias-de-design-em-2025',
    summary: 'Descubra as principais tendências de nail art e design de unhas que vão dominar 2025. De cores vibrantes a técnicas inovadoras.',
    content: `## Introdução

O mundo do nail art está em constante evolução, e 2025 promete trazer tendências incríveis que vão transformar a forma como cuidamos das nossas unhas. Neste artigo, exploramos as principais tendências que vão dominar o ano.

## Cores Vibrantes e Ousadas

As cores fortes estão de volta! Tons de marsala, rosa intenso e vermelho vinho são as apostas da temporada. Essas cores transmitem confiança e elegância, perfeitas para qualquer ocasião.

# Nail Art Minimalista

Menos é mais em 2025. O minimalismo continua em alta, com designs simples mas impactantes. Linhas finas, pontos delicados e padrões geométricos são tendências fortes.

# Texturas Inovadoras

## Acabamentos Diferentes

Experimentar com texturas é a chave. Acabamentos foscados, metálicos e holográficos criam looks únicos e modernos. A combinação de diferentes texturas em uma mesma mão também está super em alta.

# Unhas Longas e Esculturais

As unhas longas voltaram com tudo! Formatos stiletto, coffin e almond são os mais procurados, oferecendo uma tela perfeita para nail art elaboradas.

## Sustentabilidade

A preocupação com o meio ambiente também chegou ao mundo das unhas. Produtos veganos, não testados em animais e removedores sem acetona são cada vez mais populares.

Venha ao Lotus Nail Spa e experimente essas tendências com nossos profissionais especializados!`,
    cover_image: 'https://images.pexels.com/photos/3997379/pexels-photo-3997379.jpeg?auto=compress&cs=tinysrgb&w=1200',
    author_name: 'Admin',
    published: true,
  },
  {
    title: 'Como aumentar a presença digital da sua marca',
    slug: 'como-aumentar-presenca-digital-da-sua-marca',
    summary: 'Aprenda estratégias eficazes para fortalecer a presença online do seu salão de beleza e atrair mais clientes através das redes sociais.',
    content: `## A Importância da Presença Digital

No mundo digital de hoje, ter uma forte presença online não é mais opcional - é essencial. Para salões de beleza e nail spas, isso significa alcançar mais clientes e construir uma marca reconhecida.

## Redes Sociais: Sua Vitrine Virtual

# Instagram: O Rei Visual

O Instagram é perfeito para mostrar seu trabalho. Fotos de alta qualidade das unhas que você fez, vídeos do processo e stories mostrando o dia a dia do salão criam conexão com seu público.

## Dicas para Instagram de Sucesso

Publique regularmente - pelo menos 3-4 vezes por semana. Use hashtags relevantes como #nailart #manicure #nailspa. Interaja com seus seguidores respondendo comentários e mensagens.

# Facebook: Construindo Comunidade

O Facebook é excelente para criar uma comunidade. Grupos de clientes, eventos especiais e promoções funcionam muito bem nessa plataforma.

## Conteúdo de Qualidade

# O que Postar

Antes e depois das unhas, tutoriais rápidos, dicas de cuidados, promoções exclusivas e depoimentos de clientes satisfeitas.

# Quando Postar

Os melhores horários são entre 18h-21h durante a semana e sábados pela manhã. Teste e veja o que funciona melhor para seu público.

## Engajamento é Tudo

Não apenas poste - interaja! Responda comentários, faça perguntas, crie enquetes. Quanto mais você se conecta com seu público, mais forte fica sua marca.

## Promoções e Parcerias

Ofereça descontos exclusivos para seguidores, faça parcerias com influenciadoras locais e crie programas de indicação. Isso aumenta seu alcance organicamente.

No Lotus Nail Spa, usamos todas essas estratégias para nos conectar com nossas clientes. Siga-nos nas redes sociais!`,
    cover_image: 'https://images.pexels.com/photos/4348404/pexels-photo-4348404.jpeg?auto=compress&cs=tinysrgb&w=1200',
    author_name: 'Admin',
    published: true,
  },
  {
    title: 'Dicas para criar um site profissional rápido e leve',
    slug: 'dicas-para-criar-site-profissional-rapido-leve',
    summary: 'Descubra as melhores práticas para desenvolver um site profissional que seja rápido, responsivo e que converta visitantes em clientes.',
    content: `## Por que ter um site profissional?

Um site bem feito é seu cartão de visitas digital. É onde clientes em potencial conhecem seus serviços, veem seu trabalho e decidem agendar um horário.

## Design Responsivo é Obrigatório

# Mobile First

Mais de 70% das pessoas acessam sites pelo celular. Seu site PRECISA funcionar perfeitamente em dispositivos móveis. Isso não é opcional.

## Velocidade Importa

Sites lentos perdem clientes. Cada segundo de carregamento extra significa menos conversões. Use imagens otimizadas, minimize código e escolha uma hospedagem de qualidade.

# Otimização de Imagens

## Tamanho Correto

Nunca use imagens maiores que o necessário. Para uma foto de destaque, 1200px de largura é mais que suficiente. Comprima as imagens sem perder qualidade visível.

# Formatos Modernos

Use formatos modernos como WebP que oferecem melhor compressão. Para fotos de unhas, isso é especialmente importante - você quer mostrar detalhes sem peso excessivo.

## Conteúdo é Rei

# Textos Claros

Seja direto. Explique seus serviços, mostre preços, facilite o contato. Visitantes não querem procurar informações básicas.

# Call-to-Actions Efetivos

Botões de "Agendar Agora" devem estar visíveis e atraentes. Use cores que contrastem com o fundo e textos diretos.

## Experiência do Usuário

# Navegação Intuitiva

Menu claro, poucos cliques para chegar onde o cliente quer. Se alguém precisa de mais de 3 cliques para agendar, seu site pode melhorar.

## Formulários Simples

Peça apenas informações essenciais. Nome, telefone e serviço desejado são suficientes para um primeiro contato.

# Segurança

## HTTPS é Essencial

Certificado SSL não é mais diferencial - é obrigatório. Google penaliza sites sem HTTPS e clientes desconfiam.

## Manutenção Regular

Atualize seu site regularmente. Adicione novos trabalhos, atualize preços, mantenha informações de contato corretas.

O site do Lotus Nail Spa foi criado seguindo todas essas práticas. Resultado? Mais agendamentos e clientes satisfeitas!`,
    cover_image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1200',
    author_name: 'Admin',
    published: true,
  },
];

async function seedBlog() {
  console.log('Starting blog seed...');

  try {
    // First, sign up the admin user
    console.log('Creating admin user...');
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: 'romariolimadesantana30@gmail.com',
      password: '99051055',
    });

    if (authError && authError.message !== 'User already registered') {
      throw authError;
    }

    console.log('Admin user created or already exists');

    // Sign in to get the user ID
    const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
      email: 'romariolimadesantana30@gmail.com',
      password: '99051055',
    });

    if (signInError) throw signInError;

    const authorId = signInData.user.id;
    console.log('Signed in as admin, user ID:', authorId);

    // Insert sample posts
    console.log('Inserting sample posts...');

    for (const post of samplePosts) {
      const { data, error } = await supabase
        .from('blog_posts')
        .insert([
          {
            ...post,
            author_id: authorId,
          },
        ])
        .select();

      if (error) {
        console.error('Error inserting post:', post.title, error);
      } else {
        console.log('Inserted post:', post.title);
      }
    }

    console.log('Blog seed completed successfully!');
  } catch (error) {
    console.error('Error seeding blog:', error);
  }
}

seedBlog();
