import { Award, Star, Trophy } from 'lucide-react';

export function Awards() {
  const awards = [
    {
      icon: Trophy,
      title: 'Melhor Salão de Unhas',
      year: '2022'
    },
    {
      icon: Star,
      title: 'Mais Bem Avaliado',
      year: '2023'
    },
    {
      icon: Award,
      title: 'Escolha dos Clientes',
      year: '2024'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-rose-50 to-pink-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-serif text-marsala text-center mb-16 animate-fadeIn">
          Prêmios & Reconhecimento
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {awards.map((award, index) => {
            const Icon = award.icon;
            return (
              <div key={index} className="bg-white rounded-lg shadow-lg p-8 text-center hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
                <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-marsala to-rose-400 rounded-full mb-6">
                  <Icon className="w-12 h-12 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">
                  {award.title}
                </h3>
                <p className="text-marsala text-lg font-medium">
                  {award.year}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
