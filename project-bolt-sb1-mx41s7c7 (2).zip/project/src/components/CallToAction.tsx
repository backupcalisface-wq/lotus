export function CallToAction() {
  return (
    <section className="relative py-32 overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/3997392/pexels-photo-3997392.jpeg?auto=compress&cs=tinysrgb&w=1200"
          alt="Nail care background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-marsala/70" />
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-serif text-white mb-8 animate-fadeIn">
          Quer Ter Unhas Perfeitas?
        </h2>
        <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
          Agende sua consulta hoje e experimente o luxo do cuidado profissional com as unhas
        </p>
        <button className="bg-white text-marsala px-10 py-4 rounded-full text-lg font-semibold hover:bg-opacity-90 hover:scale-105 transition-all duration-300 shadow-xl">
          Agendar Agora
        </button>
      </div>
    </section>
  );
}
