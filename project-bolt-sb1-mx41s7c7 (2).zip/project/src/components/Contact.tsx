import { MapPin, Phone, Clock, Mail } from 'lucide-react';

export function Contact() {
  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-rose-50 to-pink-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-serif text-marsala text-center mb-16 animate-fadeIn">
          Visite-nos
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden h-96 border border-pink-100">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d193595.15830869428!2d-74.119763973046!3d40.69766374874431!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2s!4v1234567890123!5m2!1sen!2s"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8 border border-pink-100">
            <h3 className="text-2xl font-serif text-marsala mb-6">
              Informações de Contato
            </h3>

            <div className="space-y-6">
              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 bg-rose-50 rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-marsala group-hover:scale-110 transition-all duration-300 border border-pink-100">
                  <MapPin className="w-6 h-6 text-marsala group-hover:text-white transition-colors duration-300" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-1">Endereço</h4>
                  <p className="text-gray-600">
                    Rua da Beleza, 123<br />
                    São Paulo, SP 01234-567
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 bg-rose-50 rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-marsala group-hover:scale-110 transition-all duration-300 border border-pink-100">
                  <Phone className="w-6 h-6 text-marsala group-hover:text-white transition-colors duration-300" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-1">Telefone</h4>
                  <p className="text-gray-600">(11) 98765-4321</p>
                </div>
              </div>

              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 bg-rose-50 rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-marsala group-hover:scale-110 transition-all duration-300 border border-pink-100">
                  <Mail className="w-6 h-6 text-marsala group-hover:text-white transition-colors duration-300" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-1">Email</h4>
                  <p className="text-gray-600">contato@lotusnails.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 bg-rose-50 rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-marsala group-hover:scale-110 transition-all duration-300 border border-pink-100">
                  <Clock className="w-6 h-6 text-marsala group-hover:text-white transition-colors duration-300" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-1">Horário</h4>
                  <p className="text-gray-600">
                    Segunda - Sábado: 9:00 - 20:00<br />
                    Domingo: 10:00 - 18:00
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
