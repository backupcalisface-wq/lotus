import { AlertTriangle, Database, ExternalLink } from 'lucide-react';
import { isDatabaseConfigured } from '../lib/supabase';

export function DatabaseConfigWarning() {
  if (isDatabaseConfigured) {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-gradient-to-r from-amber-500 to-orange-500 text-white py-4 px-6 shadow-2xl">
      <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-white/20 p-2 rounded-lg backdrop-blur-sm">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-lg flex items-center gap-2">
              <Database className="w-5 h-5" />
              Banco de Dados Não Configurado
            </h3>
            <p className="text-sm text-white/90">
              Configure o Supabase para ativar todas as funcionalidades (login, newsletter, blog)
            </p>
          </div>
        </div>
        <a
          href="/DATABASE_SETUP.md"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 bg-white text-orange-600 px-6 py-2 rounded-lg font-semibold hover:bg-orange-50 transition-all duration-300 hover:scale-105 shadow-lg"
        >
          Ver Instruções
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>
    </div>
  );
}
