import { Facebook, Instagram, MessageCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  created_at: string;
}

export function Footer() {
  const [latestPosts, setLatestPosts] = useState<BlogPost[]>([]);

  useEffect(() => {
    fetchLatestPosts();
  }, []);

  const fetchLatestPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_posts')
        .select('id, title, slug, created_at')
        .eq('published', true)
        .order('created_at', { ascending: false })
        .limit(3);

      if (error) throw error;
      setLatestPosts(data || []);
    } catch (error) {
      console.error('Error fetching latest posts:', error);
    }
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="relative bg-gradient-to-br from-rose-50 to-pink-100 pt-20 pb-8">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/1458625/pexels-photo-1458625.jpeg?auto=compress&cs=tinysrgb&w=1200')] bg-cover bg-center" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif text-marsala mb-4">
            Quer Mimar Suas Unhas?
          </h2>
          <p className="text-gray-600 mb-6">
            Agende sua consulta hoje e experimente o cuidado de luxo com as unhas
          </p>
          <button className="bg-marsala text-white px-10 py-3 rounded-full text-lg hover:bg-opacity-90 hover:scale-105 transition-all duration-300 shadow-lg">
            Agendar Consulta
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div className="text-center md:text-left">
            <h3 className="text-2xl font-serif text-marsala mb-4">Lotus</h3>
            <p className="text-gray-600">
              Seu destino para cuidados de luxo com as unhas e serviços de spa.
            </p>
          </div>

          <div className="text-center">
            <h4 className="font-semibold text-marsala mb-4">Links Rápidos</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => scrollToSection('home')} className="text-gray-600 hover:text-marsala transition-all duration-300">
                  Início
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('services')} className="text-gray-600 hover:text-marsala transition-all duration-300">
                  Serviços
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('pricing')} className="text-gray-600 hover:text-marsala transition-all duration-300">
                  Preços
                </button>
              </li>
              <li>
                <Link to="/blog" className="text-gray-600 hover:text-marsala transition-all duration-300">
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          <div className="text-center">
            <h4 className="font-semibold text-marsala mb-4">Últimos Posts</h4>
            <ul className="space-y-2">
              {latestPosts.length > 0 ? (
                latestPosts.map((post) => (
                  <li key={post.id}>
                    <Link
                      to={`/blog/${post.slug}`}
                      className="text-gray-600 hover:text-marsala transition-all duration-300 text-sm line-clamp-1"
                    >
                      {post.title}
                    </Link>
                  </li>
                ))
              ) : (
                <li className="text-gray-500 text-sm">Nenhum post ainda</li>
              )}
            </ul>
          </div>

          <div className="text-center md:text-right">
            <h4 className="font-semibold text-marsala mb-4">Siga-nos</h4>
            <div className="flex justify-center md:justify-end gap-4">
              <a
                href="#"
                className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-marsala hover:bg-marsala hover:text-white hover:scale-110 transition-all duration-300 shadow-md"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-marsala hover:bg-marsala hover:text-white hover:scale-110 transition-all duration-300 shadow-md"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-marsala hover:bg-marsala hover:text-white hover:scale-110 transition-all duration-300 shadow-md"
              >
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-marsala/20 pt-8 text-center text-gray-600">
          <p>&copy; 2024 Lotus Nail Spa. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
