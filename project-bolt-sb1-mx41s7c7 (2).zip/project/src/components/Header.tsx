import { Menu, X } from 'lucide-react';
import { useState, useEffect } from 'react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className={`fixed top-0 w-full shadow-md z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white/85 backdrop-blur-md' : 'bg-white'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <h1 className="text-3xl font-serif text-marsala">Lotus</h1>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-marsala transition-all duration-300">Início</button>
            <button onClick={() => scrollToSection('services')} className="text-gray-700 hover:text-marsala transition-all duration-300">Serviços</button>
            <button onClick={() => scrollToSection('pricing')} className="text-gray-700 hover:text-marsala transition-all duration-300">Preços</button>
            <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-marsala transition-all duration-300">Sobre</button>
            <button onClick={() => scrollToSection('gallery')} className="text-gray-700 hover:text-marsala transition-all duration-300">Galeria</button>
            <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-marsala transition-all duration-300">Contato</button>
            <button className="bg-marsala text-white px-6 py-2 rounded-full hover:bg-opacity-90 hover:scale-105 transition-all duration-300 shadow-md hover:shadow-lg border border-marsala/20">
              Agendar Agora
            </button>
          </nav>

          <button
            className="md:hidden text-marsala"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMenuOpen && (
          <nav className="md:hidden pb-4 flex flex-col space-y-4">
            <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-marsala transition-all duration-300 text-left">Início</button>
            <button onClick={() => scrollToSection('services')} className="text-gray-700 hover:text-marsala transition-all duration-300 text-left">Serviços</button>
            <button onClick={() => scrollToSection('pricing')} className="text-gray-700 hover:text-marsala transition-all duration-300 text-left">Preços</button>
            <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-marsala transition-all duration-300 text-left">Sobre</button>
            <button onClick={() => scrollToSection('gallery')} className="text-gray-700 hover:text-marsala transition-all duration-300 text-left">Galeria</button>
            <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-marsala transition-all duration-300 text-left">Contato</button>
            <button className="bg-marsala text-white px-6 py-2 rounded-full hover:bg-opacity-90 transition-all duration-300 w-full border border-marsala/20">
              Agendar Agora
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}
