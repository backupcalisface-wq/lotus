import { MapPin, Clock, Phone } from 'lucide-react';

export function Hero() {
  return (
    <section id="home" className="pt-20 bg-gradient-to-br from-rose-50 to-pink-100 min-h-screen flex items-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h2 className="text-5xl md:text-6xl font-serif text-marsala mb-6 lg:mb-6 leading-tight animate-fadeIn">
              Desfrute do Melhor Cuidado de Unhas & Spa
            </h2>

            <div className="relative lg:hidden mb-6">
              <div className="relative w-full h-80 rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.pexels.com/photos/3997379/pexels-photo-3997379.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Mãos com unhas feitas"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <p className="text-xl text-gray-600 mb-8">
              Experiência Profissional e Luxuosa em Unhas
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-pink-100">
                <MapPin className="w-6 h-6 text-marsala mb-2 mx-auto md:mx-0" />
                <h3 className="font-semibold text-marsala mb-1">Localização</h3>
                <p className="text-sm text-gray-600">Rua da Beleza, 123 - SP</p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-pink-100">
                <Clock className="w-6 h-6 text-marsala mb-2 mx-auto md:mx-0" />
                <h3 className="font-semibold text-marsala mb-1">Horário</h3>
                <p className="text-sm text-gray-600">Seg-Sáb: 9h-20h</p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-pink-100">
                <Phone className="w-6 h-6 text-marsala mb-2 mx-auto md:mx-0" />
                <h3 className="font-semibold text-marsala mb-1">Contato</h3>
                <p className="text-sm text-gray-600">(11) 98765-4321</p>
              </div>
            </div>

            <div className="text-center">
              <button className="bg-marsala text-white px-10 py-4 rounded-full text-lg font-medium hover:bg-opacity-90 hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl border border-marsala/20">
                Saiba Mais
              </button>
            </div>
          </div>

          <div className="relative hidden lg:block">
            <div className="relative w-full h-[500px] rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-all duration-500">
              <img
                src="https://images.pexels.com/photos/3997379/pexels-photo-3997379.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Mãos com unhas feitas"
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
