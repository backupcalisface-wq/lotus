import { Instagram as InstagramIcon } from 'lucide-react';

export function Instagram() {
  const posts = [
    'https://images.pexels.com/photos/1445527/pexels-photo-1445527.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/4041279/pexels-photo-4041279.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/3997392/pexels-photo-3997392.jpeg?auto=compress&cs=tinysrgb&w=400',
    'https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=400'
  ];

  return (
    <section id="gallery" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center mb-4">
            <InstagramIcon className="w-10 h-10 text-marsala" />
          </div>
          <h2 className="text-4xl md:text-5xl font-serif text-marsala mb-4 animate-fadeIn">
            Veja no Instagram
          </h2>
          <p className="text-gray-600">
            Siga-nos @lotusnailspa para inspiração diária
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {posts.map((post, index) => (
            <div key={index} className="group relative overflow-hidden rounded-lg shadow-lg aspect-square cursor-pointer hover:shadow-2xl transition-all duration-300">
              <img
                src={post}
                alt={`Instagram post ${index + 1}`}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-marsala/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <InstagramIcon className="w-12 h-12 text-white" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
