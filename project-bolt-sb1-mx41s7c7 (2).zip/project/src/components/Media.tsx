import { ExternalLink } from 'lucide-react';

export function Media() {
  const articles = [
    {
      title: 'Top 10 Salões de Unhas da Cidade',
      publication: 'Revista Beleza',
      image: 'https://images.pexels.com/photos/1115128/pexels-photo-1115128.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      title: 'O Futuro das Tendências em Nail Art',
      publication: 'Estilo & Beleza',
      image: 'https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      title: 'Avaliação da Experiência Spa de Luxo',
      publication: 'Bem-Estar Hoje',
      image: 'https://images.pexels.com/photos/3997395/pexels-photo-3997395.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      title: 'Melhores Serviços de Beleza 2024',
      publication: 'Guia da Cidade',
      image: 'https://images.pexels.com/photos/3997385/pexels-photo-3997385.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-serif text-marsala text-center mb-16 animate-fadeIn">
          Mídia Sobre Nós
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {articles.map((article, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden group cursor-pointer hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
              <div className="relative h-48 overflow-hidden">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <p className="text-marsala text-sm font-semibold mb-2">
                  {article.publication}
                </p>
                <h3 className="text-gray-800 font-semibold mb-4 line-clamp-2">
                  {article.title}
                </h3>
                <div className="flex items-center text-marsala text-sm font-medium">
                  Ler Mais <ExternalLink className="w-4 h-4 ml-2" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
