export function NailMasters() {
  const masters = [
    {
      name: 'Sofia Martinez',
      specialty: 'Especialista em Nail Art',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Isabella Chen',
      specialty: 'Expert em Manicure',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Emma Johnson',
      specialty: 'Mestre em Pedicure Spa',
      image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-serif text-marsala text-center mb-16 animate-fadeIn">
          Nossas Profissionais
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {masters.map((master, index) => (
            <div key={index} className="text-center group">
              <div className="relative w-48 h-48 mx-auto mb-6 rounded-full overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300">
                <img
                  src={master.image}
                  alt={master.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <h3 className="text-2xl font-semibold text-gray-800 mb-2">
                {master.name}
              </h3>
              <p className="text-marsala font-medium">
                {master.specialty}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
