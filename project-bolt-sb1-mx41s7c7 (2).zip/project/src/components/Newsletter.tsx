import { Mail } from 'lucide-react';
import { useState, FormEvent } from 'react';
import { supabase } from '../lib/supabase';

export function Newsletter() {
  const [formData, setFormData] = useState({
    nome_completo: '',
    email: '',
    whatsapp: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage(null);

    try {
      const { error } = await supabase
        .from('newsletter_subscriptions')
        .insert([formData]);

      if (error) {
        if (error.code === '23505') {
          setMessage({ type: 'error', text: 'Este e-mail já está cadastrado!' });
        } else {
          setMessage({ type: 'error', text: 'Erro ao cadastrar. Tente novamente.' });
        }
      } else {
        setMessage({ type: 'success', text: 'Cadastro realizado com sucesso!' });
        setFormData({ nome_completo: '', email: '', whatsapp: '' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Erro ao cadastrar. Tente novamente.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-20 bg-gradient-to-br from-rose-50 to-pink-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 border-t-4 border-marsala">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-marsala to-pink-300 rounded-full mb-4">
              <Mail className="w-8 h-8 text-white" />
            </div>

            <h2 className="text-3xl md:text-4xl font-serif text-marsala mb-3">
              Receba nossas promoções
            </h2>
            <p className="text-gray-600 text-lg">
              Deixe seu e-mail e receba novidades exclusivas e descontos para cuidar das suas unhas!
            </p>
          </div>

          <form onSubmit={handleSubmit} className="max-w-[640px] mx-auto space-y-4">
            <input
              type="text"
              placeholder="Nome completo"
              value={formData.nome_completo}
              onChange={(e) => setFormData({ ...formData, nome_completo: e.target.value })}
              required
              className="w-full px-6 py-4 rounded-full border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300 text-gray-700 placeholder:text-gray-400"
            />

            <input
              type="email"
              placeholder="Seu melhor e-mail"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
              className="w-full px-6 py-4 rounded-full border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300 text-gray-700 placeholder:text-gray-400"
            />

            <input
              type="tel"
              placeholder="WhatsApp (com DDD)"
              value={formData.whatsapp}
              onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
              required
              className="w-full px-6 py-4 rounded-full border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300 text-gray-700 placeholder:text-gray-400"
            />

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-marsala to-pink-300 text-white font-semibold py-4 px-8 rounded-full hover:shadow-lg hover:scale-[1.02] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-lg border border-marsala/20"
            >
              {isSubmitting ? 'Enviando...' : 'Quero Receber'}
            </button>

            {message && (
              <div className={`text-center p-3 rounded-lg ${
                message.type === 'success'
                  ? 'bg-green-50 text-green-700'
                  : 'bg-red-50 text-red-700'
              }`}>
                {message.text}
              </div>
            )}
          </form>

          <p className="text-sm text-gray-500 text-center mt-6">
            Seus dados estão seguros conosco
          </p>
        </div>
      </div>
    </section>
  );
}
