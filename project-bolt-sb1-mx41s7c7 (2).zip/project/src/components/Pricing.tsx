export function Pricing() {
  const prices = [
    { service: 'Manicure Clássica', price: 'R$ 40' },
    { service: 'Esmaltação em Gel', price: 'R$ 70' },
    { service: 'Pedicure', price: 'R$ 50' },
    { service: 'Nail Art', price: 'R$ 30+' },
    { service: 'Manicure Francesa', price: 'R$ 60' },
    { service: 'Unhas de Acrílico', price: 'R$ 90' },
    { service: 'Pedicure Spa', price: 'R$ 80' },
    { service: 'Alongamento de Unhas', price: 'R$ 100+' }
  ];

  return (
    <section id="pricing" className="py-20 bg-gradient-to-br from-rose-50 to-pink-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-serif text-marsala text-center mb-6 animate-fadeIn">
          Nossos Preços
        </h2>
        <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
          Oferecemos preços competitivos para todos os nossos serviços premium de cuidados com as unhas.
          Cada tratamento inclui atenção personalizada e os melhores produtos.
        </p>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden mb-8 border border-pink-100">
          <div className="grid grid-cols-2 bg-marsala text-white p-4">
            <div className="font-semibold text-lg">Serviço</div>
            <div className="font-semibold text-lg text-right">Preço</div>
          </div>
          {prices.map((item, index) => (
            <div
              key={index}
              className={`grid grid-cols-2 p-4 hover:bg-rose-50 transition-colors duration-300 ${index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}`}
            >
              <div className="text-gray-800">{item.service}</div>
              <div className="text-marsala font-semibold text-right">{item.price}</div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button className="bg-marsala text-white px-8 py-3 rounded-full text-lg font-medium hover:bg-opacity-90 hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl border border-marsala/20">
            Agendar Consulta
          </button>
        </div>
      </div>
    </section>
  );
}
