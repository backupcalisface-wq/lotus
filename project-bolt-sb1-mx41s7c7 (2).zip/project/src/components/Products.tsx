
export function Products() {
  const products = [
    {
      name: 'Esmalte Rose Gold',
      price: 'R$ 35',
      image: 'https://images.pexels.com/photos/1115128/pexels-photo-1115128.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Kit Luxo de Cuidados',
      price: 'R$ 70',
      image: 'https://images.pexels.com/photos/3997398/pexels-photo-3997398.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      name: 'Top Coat Premium',
      price: 'R$ 45',
      image: 'https://images.pexels.com/photos/3997395/pexels-photo-3997395.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-rose-50 to-pink-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-serif text-marsala text-center mb-16 animate-fadeIn">
          Nossos Produtos Mais Procurados
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden group hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
              <div className="relative h-64 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">
                  {product.name}
                </h3>
                <p className="text-2xl text-marsala font-bold mb-4">
                  {product.price}
                </p>
                <button className="w-full bg-marsala text-white py-3 rounded-full hover:bg-opacity-90 hover:scale-105 transition-all duration-300">
                  Comprar Agora
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
