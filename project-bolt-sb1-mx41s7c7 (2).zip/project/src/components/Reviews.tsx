import { Star } from 'lucide-react';
import { useState } from 'react';

export function Reviews() {
  const reviews = [
    {
      name: 'Ana Silva',
      image: 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=300',
      comment: 'Serviço absolutamente incrível! A equipe é tão amigável e profissional. Minhas unhas nunca ficaram tão bonitas. Recomendo muito!',
      rating: 5
    },
    {
      name: 'Juliana Costa',
      image: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=300',
      comment: 'O melhor salão de unhas da cidade! O ambiente é tão relaxante e os resultados são sempre perfeitos. Com certeza voltarei!',
      rating: 4.5
    },
    {
      name: 'Mariana Santos',
      image: 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=300',
      comment: 'Eu amo este lugar! As manicures são incrivelmente talentosas e a atenção aos detalhes é excepcional. Vale cada centavo!',
      rating: 5
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const nextReview = () => {
    setCurrentIndex((prev) => (prev + 1) % reviews.length);
  };

  const prevReview = () => {
    setCurrentIndex((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  const review = reviews[currentIndex];

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={`full-${i}`} className="w-6 h-6 fill-marsala text-marsala" />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <div key="half" className="relative w-6 h-6">
          <Star className="w-6 h-6 text-marsala absolute" />
          <div className="absolute inset-0 overflow-hidden" style={{ width: '50%' }}>
            <Star className="w-6 h-6 fill-marsala text-marsala" />
          </div>
        </div>
      );
    }

    return stars;
  };

  return (
    <section className="py-20 bg-gradient-to-br from-rose-50 via-pink-50 to-rose-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-serif text-marsala text-center mb-16 animate-fadeIn">
          O Que Nossas Clientes Dizem
        </h2>

        <div className="relative">
          <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-16 transition-all duration-500 hover:shadow-3xl min-h-[400px] md:min-h-0 flex items-center border border-pink-100">
            <div className="flex flex-col md:flex-row items-center gap-8 w-full">
              <div className="flex-shrink-0">
                <div className="relative">
                  <div className="absolute -inset-1 bg-gradient-to-r from-marsala to-pink-300 rounded-full blur opacity-30"></div>
                  <img
                    src={review.image}
                    alt={review.name}
                    className="relative w-32 h-32 rounded-full object-cover shadow-xl ring-4 ring-white"
                  />
                </div>
              </div>

              <div className="flex-1 text-center md:text-left">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <h3 className="text-2xl font-semibold text-gray-800 mb-2 md:mb-0">
                    {review.name}
                  </h3>
                  <div className="flex justify-center md:justify-end gap-1">
                    {renderStars(review.rating)}
                  </div>
                </div>

                <p className="text-gray-600 text-lg leading-relaxed">
                  "{review.comment}"
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-center gap-6 mt-8">
            <button
              onClick={prevReview}
              className="w-12 h-12 rounded-full bg-marsala text-white hover:bg-opacity-90 hover:scale-110 transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center text-xl font-bold border border-marsala/20"
              aria-label="Avaliação anterior"
            >
              ←
            </button>
            <div className="flex items-center gap-2">
              {reviews.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentIndex
                      ? 'bg-marsala w-8'
                      : 'bg-pink-200 hover:bg-pink-300'
                  }`}
                  aria-label={`Ir para avaliação ${index + 1}`}
                />
              ))}
            </div>
            <button
              onClick={nextReview}
              className="w-12 h-12 rounded-full bg-marsala text-white hover:bg-opacity-90 hover:scale-110 transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center text-xl font-bold border border-marsala/20"
              aria-label="Próxima avaliação"
            >
              →
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
