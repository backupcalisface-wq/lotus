export function SalonInterior() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-serif text-marsala text-center mb-16 animate-fadeIn">
          Nosso Salão & Interior
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="group">
            <div className="relative overflow-hidden rounded-lg shadow-xl mb-4 h-96 hover:shadow-2xl transition-all duration-500">
              <img
                src="https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Interior luxuoso do salão"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
            <p className="text-gray-600 text-center">
              Nossa elegante e relaxante área de tratamento, projetada para seu conforto e tranquilidade.
            </p>
          </div>

          <div className="group">
            <div className="relative overflow-hidden rounded-lg shadow-xl mb-4 h-96 hover:shadow-2xl transition-all duration-500">
              <img
                src="https://images.pexels.com/photos/5029180/pexels-photo-5029180.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Espaço moderno do salão"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
            <p className="text-gray-600 text-center">
              Instalações modernas com equipamentos de última geração e comodidades luxuosas.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
