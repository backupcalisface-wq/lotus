export function WeeklyOffer() {
  return (
    <section className="relative py-32 overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/3997398/pexels-photo-3997398.jpeg?auto=compress&cs=tinysrgb&w=1200"
          alt="Weekly offer background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-marsala/80 to-rose-400/80" />
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 md:p-12">
          <h2 className="text-4xl md:text-5xl font-serif text-white mb-4 animate-fadeIn">
            Oferta da Semana
          </h2>
          <p className="text-2xl text-white mb-6">
            Ganhe 20% OFF em Esmaltação em Gel + Nail Art
          </p>
          <p className="text-white/90 text-lg mb-8">
            Válido até domingo. Agende agora para aproveitar esta oferta exclusiva!
          </p>
          <button className="bg-white text-marsala px-10 py-4 rounded-full text-lg font-semibold hover:bg-opacity-90 hover:scale-105 transition-all duration-300 shadow-xl">
            Aproveitar Oferta
          </button>
        </div>
      </div>
    </section>
  );
}
