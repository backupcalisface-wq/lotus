import { Sparkles, Award, Shield } from 'lucide-react';

export function WhyChooseUs() {
  const reasons = [
    {
      icon: Sparkles,
      title: 'Experiência Luxuosa',
      description: 'Desfrute de uma experiência premium de spa com atenção a cada detalhe'
    },
    {
      icon: Award,
      title: 'Profissionais Qualificados',
      description: 'Nossa equipe é composta por técnicos certificados e experientes'
    },
    {
      icon: Shield,
      title: 'Produtos Premium',
      description: 'Usamos apenas produtos da mais alta qualidade, seguros e duradouros'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-rose-50 to-pink-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-serif text-marsala text-center mb-16 animate-fadeIn">
          Por Que Nos Escolher
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <div key={index} className="text-center group">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-white rounded-full shadow-lg mb-6 group-hover:shadow-xl group-hover:scale-110 transition-all duration-300 border border-pink-100">
                  <Icon className="w-10 h-10 text-marsala group-hover:scale-110 transition-transform duration-300" />
                </div>
                <h3 className="text-2xl font-semibold text-marsala mb-4">
                  {reason.title}
                </h3>
                <p className="text-gray-600">
                  {reason.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
