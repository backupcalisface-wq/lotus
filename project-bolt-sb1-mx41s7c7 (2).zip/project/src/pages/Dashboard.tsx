import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Plus, CreditCard as Edit2, Trash2, LogOut, Eye, EyeOff, Key } from 'lucide-react';

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  summary: string;
  content: string;
  cover_image: string;
  published: boolean;
  created_at: string;
}

interface Usuario {
  id: string;
  email: string;
  nome: string;
  senha: string;
}

export function Dashboard() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [usuario, setUsuario] = useState<Usuario | null>(null);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    summary: '',
    content: '',
    cover_image: '',
    published: true,
  });

  const [passwordData, setPasswordData] = useState({
    senhaAtual: '',
    novaSenha: '',
    confirmarSenha: '',
  });

  const [passwordError, setPasswordError] = useState('');

  useEffect(() => {
    const usuarioLogado = localStorage.getItem('usuarioLogado');
    if (!usuarioLogado) {
      navigate('/login');
      return;
    }
    setUsuario(JSON.parse(usuarioLogado));
    fetchPosts();
  }, [navigate]);

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (editingPost) {
        const { error } = await supabase
          .from('blog_posts')
          .update(formData)
          .eq('id', editingPost.id);

        if (error) throw error;
      } else {
        const { error } = await supabase.from('blog_posts').insert([
          {
            ...formData,
            author_id: usuario?.id,
            author_name: usuario?.nome || 'Admin',
          },
        ]);

        if (error) throw error;
      }

      resetForm();
      fetchPosts();
    } catch (error: any) {
      alert(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este post?')) return;

    try {
      const { error } = await supabase.from('blog_posts').delete().eq('id', id);

      if (error) throw error;
      fetchPosts();
    } catch (error: any) {
      alert(error.message);
    }
  };

  const handleEdit = (post: BlogPost) => {
    setEditingPost(post);
    setFormData({
      title: post.title,
      slug: post.slug,
      summary: post.summary,
      content: post.content,
      cover_image: post.cover_image,
      published: post.published,
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setFormData({
      title: '',
      slug: '',
      summary: '',
      content: '',
      cover_image: '',
      published: true,
    });
    setEditingPost(null);
    setShowForm(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('usuarioLogado');
    navigate('/login');
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');

    if (!usuario) return;

    if (passwordData.senhaAtual !== usuario.senha) {
      setPasswordError('Senha atual incorreta');
      return;
    }

    if (passwordData.novaSenha !== passwordData.confirmarSenha) {
      setPasswordError('As senhas não coincidem');
      return;
    }

    if (passwordData.novaSenha.length < 6) {
      setPasswordError('A nova senha deve ter no mínimo 6 caracteres');
      return;
    }

    try {
      const { error } = await supabase
        .from('usuarios')
        .update({ senha: passwordData.novaSenha })
        .eq('id', usuario.id);

      if (error) throw error;

      const usuarioAtualizado = { ...usuario, senha: passwordData.novaSenha };
      setUsuario(usuarioAtualizado);
      localStorage.setItem('usuarioLogado', JSON.stringify(usuarioAtualizado));

      alert('Senha alterada com sucesso!');
      setShowPasswordModal(false);
      setPasswordData({ senhaAtual: '', novaSenha: '', confirmarSenha: '' });
    } catch (error: any) {
      setPasswordError(error.message || 'Erro ao alterar senha');
    }
  };

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-pink-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-serif text-marsala">Dashboard</h1>
            {usuario && <p className="text-gray-600 mt-2">Olá, {usuario.nome}</p>}
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => setShowPasswordModal(true)}
              className="flex items-center gap-2 bg-white text-marsala px-6 py-2 rounded-full hover:bg-rose-50 transition-all duration-300 shadow-md border border-marsala/20"
            >
              <Key className="w-4 h-4" />
              Alterar Senha
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 bg-marsala text-white px-6 py-2 rounded-full hover:bg-opacity-90 transition-all duration-300 shadow-md border border-marsala/20"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </button>
          </div>
        </div>

        <div className="mb-6">
          <button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 bg-gradient-to-r from-marsala to-pink-300 text-white px-6 py-3 rounded-full hover:shadow-lg transition-all duration-300 border border-marsala/20"
          >
            <Plus className="w-5 h-5" />
            {showForm ? 'Cancelar' : 'Novo Post'}
          </button>
        </div>

        {showForm && (
          <div className="bg-white rounded-2xl shadow-xl p-8 mb-8 border border-pink-100">
            <h2 className="text-2xl font-serif text-marsala mb-6">
              {editingPost ? 'Editar Post' : 'Criar Novo Post'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Título
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => {
                    setFormData({ ...formData, title: e.target.value });
                    if (!editingPost) {
                      setFormData({
                        ...formData,
                        title: e.target.value,
                        slug: generateSlug(e.target.value),
                      });
                    }
                  }}
                  required
                  className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Slug (URL)
                </label>
                <input
                  type="text"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  required
                  className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Resumo
                </label>
                <textarea
                  value={formData.summary}
                  onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                  required
                  rows={3}
                  className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Conteúdo
                </label>
                <textarea
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  required
                  rows={10}
                  className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300 font-mono text-sm"
                  placeholder="Use ## para títulos e # para subtítulos"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  URL da Imagem de Capa
                </label>
                <input
                  type="url"
                  value={formData.cover_image}
                  onChange={(e) => setFormData({ ...formData, cover_image: e.target.value })}
                  required
                  className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="published"
                  checked={formData.published}
                  onChange={(e) => setFormData({ ...formData, published: e.target.checked })}
                  className="w-5 h-5 text-marsala rounded focus:ring-marsala"
                />
                <label htmlFor="published" className="text-sm font-medium text-gray-700">
                  Publicar post
                </label>
              </div>

              <div className="flex gap-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="bg-gradient-to-r from-marsala to-pink-300 text-white px-6 py-3 rounded-lg hover:shadow-lg transition-all duration-300 disabled:opacity-50 border border-marsala/20"
                >
                  {editingPost ? 'Atualizar' : 'Criar'} Post
                </button>
                {editingPost && (
                  <button
                    type="button"
                    onClick={resetForm}
                    className="bg-gray-200 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-300 transition-all duration-300"
                  >
                    Cancelar Edição
                  </button>
                )}
              </div>
            </form>
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-pink-100">
          <div className="px-6 py-4 bg-gradient-to-r from-marsala to-pink-300">
            <h2 className="text-xl font-semibold text-white">Posts</h2>
          </div>

          <div className="divide-y divide-pink-100">
            {posts.length === 0 ? (
              <div className="p-8 text-center text-gray-600">
                Nenhum post criado ainda.
              </div>
            ) : (
              posts.map((post) => (
                <div key={post.id} className="p-6 hover:bg-rose-50 transition-colors duration-200">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-lg font-semibold text-gray-800">{post.title}</h3>
                        {post.published ? (
                          <Eye className="w-4 h-4 text-green-600" />
                        ) : (
                          <EyeOff className="w-4 h-4 text-gray-400" />
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{post.summary}</p>
                      <p className="text-xs text-gray-500">
                        {new Date(post.created_at).toLocaleDateString('pt-BR')}
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handleEdit(post)}
                        className="p-2 text-marsala hover:bg-marsala hover:text-white rounded-lg transition-all duration-300 border border-pink-200"
                      >
                        <Edit2 className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleDelete(post.id)}
                        className="p-2 text-red-600 hover:bg-red-600 hover:text-white rounded-lg transition-all duration-300 border border-red-200"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {showPasswordModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full border border-pink-100">
              <h2 className="text-2xl font-serif text-marsala mb-6">Alterar Senha</h2>

              <form onSubmit={handleChangePassword} className="space-y-4">
                {passwordError && (
                  <div className="bg-red-50 text-red-700 p-3 rounded-lg text-sm border border-red-100">
                    {passwordError}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Senha Atual
                  </label>
                  <input
                    type="password"
                    value={passwordData.senhaAtual}
                    onChange={(e) => setPasswordData({ ...passwordData, senhaAtual: e.target.value })}
                    required
                    className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300"
                    placeholder="Digite sua senha atual"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nova Senha
                  </label>
                  <input
                    type="password"
                    value={passwordData.novaSenha}
                    onChange={(e) => setPasswordData({ ...passwordData, novaSenha: e.target.value })}
                    required
                    className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300"
                    placeholder="Digite a nova senha"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Confirmar Nova Senha
                  </label>
                  <input
                    type="password"
                    value={passwordData.confirmarSenha}
                    onChange={(e) => setPasswordData({ ...passwordData, confirmarSenha: e.target.value })}
                    required
                    className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300"
                    placeholder="Confirme a nova senha"
                  />
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-marsala to-pink-300 text-white px-6 py-3 rounded-lg hover:shadow-lg transition-all duration-300 border border-marsala/20"
                  >
                    Alterar Senha
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowPasswordModal(false);
                      setPasswordData({ senhaAtual: '', novaSenha: '', confirmarSenha: '' });
                      setPasswordError('');
                    }}
                    className="flex-1 bg-gray-200 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-300 transition-all duration-300"
                  >
                    Cancelar
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
