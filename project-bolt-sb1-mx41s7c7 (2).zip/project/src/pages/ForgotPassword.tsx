import { useState, FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Mail, Lock } from 'lucide-react';

export function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<'email' | 'password'>('email');
  const [userId, setUserId] = useState<string>('');

  const handleEmailSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      const { data: usuario, error: dbError } = await supabase
        .from('usuarios')
        .select('id')
        .eq('email', email)
        .maybeSingle();

      if (dbError) throw dbError;

      if (!usuario) {
        setError('⚠️ E-mail não encontrado no sistema.');
        setLoading(false);
        return;
      }

      setUserId(usuario.id);
      setStep('password');
      setSuccess('✅ E-mail encontrado! Agora defina sua nova senha.');
    } catch (err: any) {
      setError(err.message || 'Erro ao verificar e-mail. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    if (newPassword !== confirmPassword) {
      setError('⚠️ As senhas não coincidem.');
      setLoading(false);
      return;
    }

    if (newPassword.length < 6) {
      setError('⚠️ A senha deve ter no mínimo 6 caracteres.');
      setLoading(false);
      return;
    }

    try {
      const { error: updateError } = await supabase
        .from('usuarios')
        .update({ senha: newPassword })
        .eq('id', userId);

      if (updateError) throw updateError;

      setSuccess('🔑 Senha redefinida com sucesso! Redirecionando...');
      setTimeout(() => {
        window.location.href = '/login?reset=success';
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Erro ao alterar senha. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-rose-50 to-pink-100 py-12 px-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-3xl shadow-2xl p-8 border border-pink-100">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-marsala to-pink-300 rounded-full mb-4">
              {step === 'email' ? <Mail className="w-8 h-8 text-white" /> : <Lock className="w-8 h-8 text-white" />}
            </div>
            <h2 className="text-3xl font-serif text-marsala mb-2">Recuperar Senha</h2>
            <p className="text-gray-600">
              {step === 'email' ? 'Informe seu e-mail cadastrado' : 'Defina sua nova senha'}
            </p>
          </div>

          {success && (
            <div className="bg-green-50 text-green-700 p-4 rounded-lg text-sm border border-green-100 mb-4">
              {success}
            </div>
          )}

          {error && (
            <div className="bg-red-50 text-red-700 p-3 rounded-lg text-sm border border-red-100 mb-4">
              {error}
            </div>
          )}

          {step === 'email' ? (
            <form onSubmit={handleEmailSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  E-mail
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300"
                  placeholder="seu@email.com"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-marsala to-pink-300 text-white font-semibold py-3 px-6 rounded-lg hover:shadow-lg hover:scale-[1.02] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed border border-marsala/20"
              >
                {loading ? 'Verificando...' : 'Continuar'}
              </button>
            </form>
          ) : (
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nova Senha
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300"
                  placeholder="••••••••"
                  minLength={6}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Confirmar Nova Senha
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="w-full px-4 py-3 rounded-lg border-2 border-pink-200 focus:border-marsala focus:outline-none focus:ring-2 focus:ring-marsala/20 transition-all duration-300"
                  placeholder="••••••••"
                  minLength={6}
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-marsala to-pink-300 text-white font-semibold py-3 px-6 rounded-lg hover:shadow-lg hover:scale-[1.02] transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed border border-marsala/20"
              >
                {loading ? 'Alterando...' : 'Alterar Senha'}
              </button>
            </form>
          )}

          <div className="mt-6 text-center space-y-3">
            <Link
              to="/login"
              className="block text-sm text-gray-600 hover:text-marsala transition-colors duration-300"
            >
              Voltar para o login
            </Link>
            <Link
              to="/"
              className="block text-sm text-gray-600 hover:text-marsala transition-colors duration-300"
            >
              ← Voltar para o site
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
