import { Hero } from '../components/Hero';
import { FeaturedServices } from '../components/FeaturedServices';
import { WhyChooseUs } from '../components/WhyChooseUs';
import { Pricing } from '../components/Pricing';
import { SalonInterior } from '../components/SalonInterior';
import { NailMasters } from '../components/NailMasters';
import { Products } from '../components/Products';
import { WeeklyOffer } from '../components/WeeklyOffer';
import { Reviews } from '../components/Reviews';
import { Instagram } from '../components/Instagram';
import { Awards } from '../components/Awards';
import { Media } from '../components/Media';
import { CallToAction } from '../components/CallToAction';
import { Newsletter } from '../components/Newsletter';
import { Contact } from '../components/Contact';

export function Home() {
  return (
    <>
      <Hero />
      <FeaturedServices />
      <WhyChooseUs />
      <Pricing />
      <SalonInterior />
      <NailMasters />
      <Products />
      <WeeklyOffer />
      <Reviews />
      <Instagram />
      <Awards />
      <Media />
      <CallToAction />
      <Newsletter />
      <Contact />
    </>
  );
}
