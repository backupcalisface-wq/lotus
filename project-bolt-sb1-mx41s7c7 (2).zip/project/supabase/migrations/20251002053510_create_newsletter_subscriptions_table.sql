/*
  # Create Newsletter Subscriptions Table

  ## Summary
  Creates a table to store newsletter subscription information for the nail salon.

  ## New Tables
    - `newsletter_subscriptions`
      - `id` (uuid, primary key) - Unique identifier for each subscription
      - `nome_completo` (text) - Full name of the subscriber
      - `email` (text, unique) - Email address (unique to prevent duplicates)
      - `whatsapp` (text) - WhatsApp phone number with country code
      - `created_at` (timestamptz) - Timestamp when subscription was created
      - `updated_at` (timestamptz) - Timestamp when record was last updated

  ## Security
    - Enable Row Level Security (RLS) on `newsletter_subscriptions` table
    - Add policy for anonymous users to insert their own subscriptions
    - Add policy for authenticated users to read all subscriptions (for admin access)

  ## Important Notes
    1. Email field has a unique constraint to prevent duplicate subscriptions
    2. All fields except id and timestamps are required (NOT NULL)
    3. RLS is enabled to protect subscriber data
    4. Anonymous users can only insert (subscribe), not read other subscribers
    5. Authenticated users (salon staff) can view all subscriptions
*/

CREATE TABLE IF NOT EXISTS newsletter_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome_completo text NOT NULL,
  email text UNIQUE NOT NULL,
  whatsapp text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE newsletter_subscriptions ENABLE ROW LEVEL SECURITY;

-- Policy: Allow anyone to insert (subscribe)
CREATE POLICY "Anyone can subscribe to newsletter"
  ON newsletter_subscriptions
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Policy: Allow authenticated users to read all subscriptions
CREATE POLICY "Authenticated users can view all subscriptions"
  ON newsletter_subscriptions
  FOR SELECT
  TO authenticated
  USING (true);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_newsletter_email ON newsletter_subscriptions(email);

-- Create index on created_at for sorting
CREATE INDEX IF NOT EXISTS idx_newsletter_created_at ON newsletter_subscriptions(created_at DESC);