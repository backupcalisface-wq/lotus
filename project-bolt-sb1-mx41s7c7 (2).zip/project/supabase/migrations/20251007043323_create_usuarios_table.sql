/*
  # Create Usuarios Table

  ## Summary
  Creates a simple usuarios (users) table for custom authentication with plain text passwords.

  ## New Tables
    - `usuarios`
      - `id` (uuid, primary key) - Unique identifier for each user
      - `email` (text, unique) - Email address (unique for each client)
      - `senha` (text) - Password in plain text (default: admin123)
      - `nome` (text) - User's full name
      - `created_at` (timestamptz) - Timestamp when user was created
      - `updated_at` (timestamptz) - Timestamp when record was last updated

  ## Security
    - Enable Row Level Security (RLS) on `usuarios` table
    - Allow authenticated users to read their own data
    - Allow authenticated users to update their own password

  ## Important Notes
    1. Email field has a unique constraint to prevent duplicate accounts
    2. Passwords are stored in plain text (for development only)
    3. Default password is 'admin123' for all new users
    4. Users can update their own password through the dashboard
*/

CREATE TABLE IF NOT EXISTS usuarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  senha text NOT NULL DEFAULT 'admin123',
  nome text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;

-- Policy: Users can read their own data
CREATE POLICY "Users can read own data"
  ON usuarios
  FOR SELECT
  USING (true);

-- Policy: Users can update their own password
CREATE POLICY "Users can update own password"
  ON usuarios
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_usuarios_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for updated_at
DROP TRIGGER IF EXISTS usuarios_updated_at ON usuarios;
CREATE TRIGGER usuarios_updated_at
  BEFORE UPDATE ON usuarios
  FOR EACH ROW
  EXECUTE FUNCTION update_usuarios_updated_at();

-- Insert a default admin user for testing
INSERT INTO usuarios (email, senha, nome) 
VALUES ('admin@salon.com', 'admin123', 'Administrador')
ON CONFLICT (email) DO NOTHING;