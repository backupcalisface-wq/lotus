/*
  # Create usuarios table with admin user

  1. New Tables
    - `usuarios`
      - `id` (uuid, primary key, auto-generated)
      - `nome` (text, user's name)
      - `email` (text, unique, user's email)
      - `senha` (text, user's password)
      - `created_at` (timestamptz, creation timestamp)

  2. Security
    - Enable RLS on `usuarios` table
    - Add policy for authenticated users to read their own data
    - Add policy for users to update their own password

  3. Initial Data
    - Insert admin user with email romariolimadesantana30@gmail.com
*/

-- Create usuarios table
CREATE TABLE IF NOT EXISTS usuarios (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nome text NOT NULL,
  email text UNIQUE NOT NULL,
  senha text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;

-- Policy: Users can read their own data
CREATE POLICY "Users can read own data"
  ON usuarios
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = id::text);

-- Policy: Users can update their own password
CREATE POLICY "Users can update own password"
  ON usuarios
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = id::text)
  WITH CHECK (auth.uid()::text = id::text);

-- Policy: Allow public read for login purposes (temporary, can be restricted later)
CREATE POLICY "Allow login verification"
  ON usuarios
  FOR SELECT
  TO anon
  USING (true);

-- Insert admin user
INSERT INTO usuarios (nome, email, senha)
VALUES ('Administrador', 'romariolimadesantana30@gmail.com', 'admin123')
ON CONFLICT (email) DO NOTHING;