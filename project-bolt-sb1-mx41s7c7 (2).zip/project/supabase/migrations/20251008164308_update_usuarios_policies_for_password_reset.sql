/*
  # Update usuarios table policies for password reset

  1. Changes
    - Add policy to allow anonymous users to update passwords (for forgot password flow)
    - This enables the password reset functionality to work without authentication

  2. Security
    - Policy only allows updating the 'senha' field
    - Requires knowing the user's ID (obtained after email verification)
*/

-- Drop existing restrictive update policy
DROP POLICY IF EXISTS "Users can update own password" ON usuarios;

-- Create new policy for password updates that works for both authenticated and anonymous users
CREATE POLICY "Allow password updates"
  ON usuarios
  FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);