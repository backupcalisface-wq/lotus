/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'marsala': '#C06C84',
        'rose-pink': '#FDECEE',
      },
      fontFamily: {
        'serif': ['Cormorant', 'serif'],
        'sans': ['Poppins', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
